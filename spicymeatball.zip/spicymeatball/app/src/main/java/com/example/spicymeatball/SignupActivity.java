package com.example.spicymeatball;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.spicymeatball.ui.login.LoginActivity;

public class SignupActivity extends Activity {
    TextView msg;
    EditText emailText;
    EditText passwordText;
    EditText phoneText;
    Button confirmbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_activity);
        msg = findViewById(R.id.signup_text);
        emailText = findViewById(R.id.signup_email);
        passwordText = findViewById(R.id.signup_password);
        phoneText = findViewById(R.id.phoneNo);
        confirmbtn = findViewById(R.id.confirm_signup);

        confirmbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String confirmationPrompt = "Welcome aboard!";
                Toast.makeText(getApplicationContext(), confirmationPrompt, Toast.LENGTH_LONG).show();
                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(i);
            }
        });
    }
}

